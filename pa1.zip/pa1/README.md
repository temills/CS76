Run test cases for foxes and chicken problem using "./foxes.py"
The lossy version of FoxProblem.py and test cases are commented out.
