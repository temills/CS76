Run multitobot problem with ./test_mazeworld.py.
Run sensorless problem with ./test_sensorless.py
Generate new mazes with ./generate_maze.py